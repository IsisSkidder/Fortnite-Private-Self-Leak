/*

Visual#9999, Updated by bunyip24#9999 
*/
#pragma once
#include <wtypes.h>

namespace SettingsHelper {
	VOID Initialize();
	VOID SaveSettings();
}